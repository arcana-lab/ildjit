var searchData=
[
  ['allocalignedmemoryfunction',['allocAlignedMemoryFunction',['../group___compiler_memory.html#gac30af05fbb28ac706ce91b411f0d3d5b',1,'compiler_memory_manager.h']]],
  ['allocfunction',['allocFunction',['../group___compiler_memory.html#ga9e832988d6e722a94145216bd960e8cc',1,'compiler_memory_manager.h']]],
  ['architecture_5fid_5fto_5fstring',['architecture_ID_to_string',['../iljit-utils_8h.html#aa02ddd9dc552edaef94b2932c3e38e72',1,'iljit-utils.h']]]
];
