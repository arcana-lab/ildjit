var searchData=
[
  ['header',['header',['../structloop__t.html#a03de333e2dbe5000d22490962a20d25c',1,'loop_t']]],
  ['header_5fid',['header_id',['../structcircuit__t.html#ae066c3f284fdf4b67e8672e8465458af',1,'circuit_t']]]
];
