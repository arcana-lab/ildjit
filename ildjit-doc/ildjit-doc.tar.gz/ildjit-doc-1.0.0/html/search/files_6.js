var searchData=
[
  ['shared_5fmemory_5fpool_2eh',['shared_memory_pool.h',['../shared__memory__pool_8h.html',1,'']]],
  ['system_5finitializer_2eh',['system_initializer.h',['../system__initializer_8h.html',1,'']]],
  ['system_5fmanager_2eh',['system_manager.h',['../system__manager_8h.html',1,'']]]
];
