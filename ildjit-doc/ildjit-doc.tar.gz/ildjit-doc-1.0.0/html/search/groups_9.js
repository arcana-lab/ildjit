var searchData=
[
  ['jump_20instruction_20set',['Jump instruction set',['../group___i_r_language_instructions_jump.html',1,'']]]
];
