var searchData=
[
  ['b',['b',['../structinduction__variable__t.html#ab1c39234b2fb9e0c89449de16490bbc1',1,'induction_variable_t']]],
  ['backedge',['backEdge',['../structcircuit__t.html#ac704b13c66ddf10dc2815bb2fe378783',1,'circuit_t']]],
  ['backedges',['backedges',['../structloop__t.html#a4dea63c5aa8de5f6f84b2dbbae6b9a12',1,'loop_t']]],
  ['basicblocks',['basicBlocks',['../structir__method__t.html#a2ede138e2515a78f04bf772cf6790236',1,'ir_method_t']]],
  ['basicblockstop',['basicBlocksTop',['../structir__method__t.html#a93581b0348649d0d1da0768317ac88d0',1,'ir_method_t']]],
  ['behavior',['behavior',['../struct_i_r_v_m__t.html#ab76edc8ce6d4c0d805e80356eb5dbd8a',1,'IRVM_t']]],
  ['belong_5finst',['belong_inst',['../structcircuit__t.html#a3ccfd9a07aab5a29bd24a2125ffd0e5a',1,'circuit_t']]],
  ['bootstrap_5ftime',['bootstrap_time',['../structt__profiler.html#ae8d72d1fa6d98bbbe309b12c945f939e',1,'t_profiler']]],
  ['buildmethod',['buildMethod',['../structclr__interface__t.html#af8c1e9d699f70def68f23e3d25a77b95',1,'clr_interface_t']]],
  ['byte_5foffset',['byte_offset',['../structir__instruction__t.html#a0997b30e1bf57d6ab2f364965f71de19',1,'ir_instruction_t']]]
];
