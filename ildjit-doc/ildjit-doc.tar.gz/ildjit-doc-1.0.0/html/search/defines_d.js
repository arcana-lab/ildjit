var searchData=
[
  ['param_5ftable',['PARAM_TABLE',['../ecma__constant_8h.html#a5aab66f6549ef91553fcb68840eba529',1,'ecma_constant.h']]],
  ['pop_5fopcode',['POP_OPCODE',['../cil__opcodes_8h.html#aed0665dad007ece831062d56becb2fd8',1,'cil_opcodes.h']]],
  ['prefixref_5fopcode',['PREFIXREF_OPCODE',['../cil__opcodes_8h.html#a223696523769daeb70159396c47c4f50',1,'cil_opcodes.h']]],
  ['property_5fmap_5ftable',['PROPERTY_MAP_TABLE',['../ecma__constant_8h.html#afc244e252b32069c80505f749e90d249',1,'ecma_constant.h']]],
  ['property_5ftable',['PROPERTY_TABLE',['../ecma__constant_8h.html#abf7abcbbc4894f88f915d5f0fe0ee872',1,'ecma_constant.h']]]
];
