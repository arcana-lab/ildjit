var searchData=
[
  ['read_5ffrom_5fbuffer',['read_from_buffer',['../iljit-utils_8h.html#a3782e5c774a48ff91b29919a60446325',1,'iljit-utils.h']]],
  ['readonly_5fopcode',['READONLY_OPCODE',['../cil__opcodes_8h.html#a8d5dd04b65e5d25bbbe29dece63d3ae8',1,'cil_opcodes.h']]],
  ['refanytype_5fopcode',['REFANYTYPE_OPCODE',['../cil__opcodes_8h.html#aabfc337140ee1179bfb1c2bd3ad255be',1,'cil_opcodes.h']]],
  ['refanyval_5fopcode',['REFANYVAL_OPCODE',['../cil__opcodes_8h.html#abf3cec20d8252f3a1dc8114f84c5d049',1,'cil_opcodes.h']]],
  ['rem_5fopcode',['REM_OPCODE',['../cil__opcodes_8h.html#a79b36d92f0e4abbcf8ba22c5de1df4b6',1,'cil_opcodes.h']]],
  ['rem_5fun_5fopcode',['REM_UN_OPCODE',['../cil__opcodes_8h.html#ac3e60a80aae28679fe696e77c9fa43fa',1,'cil_opcodes.h']]],
  ['ret_5fopcode',['RET_OPCODE',['../cil__opcodes_8h.html#ad227589147f391329066af2091b4e94a',1,'cil_opcodes.h']]],
  ['rethrow_5fopcode',['RETHROW_OPCODE',['../cil__opcodes_8h.html#a75f238b39471f152a5cb2291d4b270f6',1,'cil_opcodes.h']]]
];
