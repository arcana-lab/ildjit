var searchData=
[
  ['earliestexpressionsblocknumbers',['earliestExpressionsBlockNumbers',['../structir__method__t.html#a02221e983ed0e39f9b0a75b84e186136',1,'ir_method_t']]],
  ['edges',['edges',['../struct_xan_graph.html#a56ccc59a8d2b2e8a6aab07e1c3626c2a',1,'XanGraph']]],
  ['endinst',['endInst',['../struct_i_r_basic_block.html#a4afeb12b8ef67ae5447061bd43e1a87c',1,'IRBasicBlock']]],
  ['exception_5fsystem',['exception_system',['../structt__system.html#a11b8d622cc61e78f9a8334d1f02d4d6b',1,'t_system']]],
  ['execution_5ftime',['execution_time',['../structt__profiler.html#a943af019460e159d56de5bc64c5f8c3d',1,'t_profiler']]],
  ['executionprobability',['executionProbability',['../structir__instruction__t.html#aaca5587acac40ecc2e3a0ce674f4af01',1,'ir_instruction_t']]],
  ['exitnode',['exitNode',['../structir__method__t.html#a99b1b5c064ee1cfeb74ea875181f05eb',1,'ir_method_t']]],
  ['exits',['exits',['../structloop__t.html#a28937326ef8e18c5c562d8e4b5c145e9',1,'loop_t']]]
];
