var searchData=
[
  ['staticmemorymanager',['StaticMemoryManager',['../struct_static_memory_manager.html',1,'']]]
];
