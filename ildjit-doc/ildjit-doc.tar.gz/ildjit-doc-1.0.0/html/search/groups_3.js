var searchData=
[
  ['dynamic_20linking',['Dynamic linking',['../group___d_y_n_l_i_n_k_s.html',1,'']]],
  ['directories',['Directories',['../group___f_i_l_e_s___d_i_r.html',1,'']]],
  ['data_20type',['Data type',['../group___i_l_t_y_p_e.html',1,'']]],
  ['debugging',['Debugging',['../group___i_r_debugging.html',1,'']]],
  ['data_20types',['Data types',['../group___i_r_language_data_types.html',1,'']]],
  ['data_20type',['Data type',['../group___i_r_m_e_t_h_o_d___code_transformation_data_type.html',1,'']]],
  ['data_20dependences',['Data dependences',['../group___i_r_m_e_t_h_o_d___data_dependences.html',1,'']]],
  ['data_20type',['Data type',['../group___i_r_m_e_t_h_o_d___data_type.html',1,'']]],
  ['dependences',['Dependences',['../group___i_r_m_e_t_h_o_d___dependences.html',1,'']]],
  ['delete_20instructions',['Delete instructions',['../group___i_r_m_e_t_h_o_d___modify_methods_deleting_instructions.html',1,'']]],
  ['data_20flow_20analysis',['Data flow analysis',['../group___i_r_m_e_t_h_o_d_m_e_t_a_d_a_t_a___data_flow.html',1,'']]],
  ['destroy_20a_20hash_20table',['Destroy a hash table',['../group___xan_hash_table_destroy.html',1,'']]],
  ['data_20structure_20api',['Data structure API',['../group___xan_lib_doc.html',1,'']]],
  ['destroy_20a_20list',['Destroy a list',['../group___xan_list_destroy.html',1,'']]]
];
