var searchData=
[
  ['reachingdefinitionsblocknumbers',['reachingDefinitionsBlockNumbers',['../structir__method__t.html#a1c0a35776155113b47cf2c5497b3a3dd',1,'ir_method_t']]],
  ['reachingexpressionsblocknumbers',['reachingExpressionsBlockNumbers',['../structir__method__t.html#a948ae905b7e94df401a1471d42d58498',1,'ir_method_t']]],
  ['reader',['reader',['../structt__binary.html#a6db224c0d68718b173358c1f94e1efe1',1,'t_binary']]],
  ['recompilerfunction',['recompilerFunction',['../struct_i_r_v_m__t.html#a0b06ced1c5c11a320cf46149704bf961',1,'IRVM_t']]],
  ['registercompilationdone',['registerCompilationDone',['../struct_static_memory_manager.html#a8b2742345dca3515122f405603c687ec',1,'StaticMemoryManager']]],
  ['registercompilationneeded',['registerCompilationNeeded',['../struct_static_memory_manager.html#ac6175ed372a9b1d567d535f81ead5157',1,'StaticMemoryManager']]],
  ['resolve',['resolve',['../struct___i_r_symbol_type.html#acfc798a4a4aafa213ea8992654cfe31f',1,'_IRSymbolType']]],
  ['result',['result',['../structir__instruction__t.html#a66b20ee97683316c039681c09d82c020',1,'ir_instruction_t']]],
  ['resulttype',['resultType',['../structir__signature__t.html#aaa4c617b03054991e2021360379f2f0f',1,'ir_signature_t']]]
];
