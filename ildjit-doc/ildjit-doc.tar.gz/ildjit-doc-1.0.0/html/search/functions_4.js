var searchData=
[
  ['freefunction',['freeFunction',['../group___compiler_memory.html#gadbe3d45a2afdbb755f48aef7ed522d77',1,'compiler_memory_manager.h']]]
];
