var searchData=
[
  ['a',['a',['../structinduction__variable__t.html#a0950ce88eb6ef192834c98bbe6bd7594',1,'induction_variable_t']]],
  ['addchildren',['addChildren',['../struct_xan_node.html#a0619097e6a7f372666149ea099f95013',1,'XanNode']]],
  ['addnewchildren',['addNewChildren',['../struct_xan_node.html#aa56ec5686db5512a5933bdce5187edc6',1,'XanNode']]],
  ['alias',['alias',['../structir__instruction__metadata__t.html#aa4c080fee05d917ebdb884e4c307c711',1,'ir_instruction_metadata_t']]],
  ['alloc',['alloc',['../struct_xan_list.html#af0c60171aee9dd975f3b3727337ca751',1,'XanList::alloc()'],['../struct_xan_stack.html#af0c60171aee9dd975f3b3727337ca751',1,'XanStack::alloc()']]],
  ['anticipatedexpressionsblocknumbers',['anticipatedExpressionsBlockNumbers',['../structir__method__t.html#ac1ed97317e7f936ff1978c465246f0df',1,'ir_method_t']]],
  ['arg',['arg',['../structt__system.html#ae32a6169139597c4793aefbab4a130ae',1,'t_system']]],
  ['assemblies_5fdecoded',['assemblies_decoded',['../structt__plugins.html#ad61c0cba0e5f2c650b98757fa9513cec',1,'t_plugins']]],
  ['availableexpressionsblocknumbers',['availableExpressionsBlockNumbers',['../structir__method__t.html#a7dd223979cc29e166b59196fcbb70083',1,'ir_method_t']]],
  ['average_5fpipeline_5flatency',['average_pipeline_latency',['../structt__profiler.html#a63ec9f640083c39457692d920768a4f0',1,'t_profiler']]]
];
