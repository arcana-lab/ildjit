var searchData=
[
  ['optimization_20level_20tools',['Optimization level tools',['../group___optimizationleveltools.html',1,'']]],
  ['optimizations',['optimizations',['../structir__system__behavior__t.html#acfbdbdca74cd1b25e0179b175e273757',1,'ir_system_behavior_t']]],
  ['optimizer',['optimizer',['../struct_i_r_v_m__t.html#aa5dae0d450ac20c09914e0f3db971c85',1,'IRVM_t']]],
  ['or_5fopcode',['OR_OPCODE',['../cil__opcodes_8h.html#a65db56a330b36f4216176a36fea024df',1,'cil_opcodes.h']]],
  ['outgoingedges',['outgoingEdges',['../struct_xan_graph_node.html#a809f32c6f00f8e15bdaa05ccd899db45',1,'XanGraphNode']]],
  ['outsideinstructions',['outsideInstructions',['../structdata__dep__arc__list__t.html#a42d20d1067d765081f4658b4690606f1',1,'data_dep_arc_list_t']]],
  ['overview',['Overview',['../group___overview.html',1,'']]],
  ['owner',['owner',['../struct_i_l_j_i_t_monitor.html#a4853b85f5f1313f7cafe4da2a367e95c',1,'ILJITMonitor']]]
];
