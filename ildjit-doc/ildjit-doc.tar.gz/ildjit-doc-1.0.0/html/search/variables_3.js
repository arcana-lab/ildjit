var searchData=
[
  ['data',['data',['../struct_xan_list_item.html#a735984d41155bc1032e09bece8f8d66d',1,'XanListItem::data()'],['../struct_xan_graph_node.html#a735984d41155bc1032e09bece8f8d66d',1,'XanGraphNode::data()'],['../struct_xan_graph_edge.html#a735984d41155bc1032e09bece8f8d66d',1,'XanGraphEdge::data()'],['../struct_xan_graph.html#a735984d41155bc1032e09bece8f8d66d',1,'XanGraph::data()'],['../struct_xan_bit_set.html#adb04825e910a0d40a43fe600dff0e779',1,'XanBitSet::data()']]],
  ['decode_5fimage',['decode_image',['../structt__plugins.html#af38ac7c3cde1383d02251cb8f0ca9a6d',1,'t_plugins']]],
  ['deletechildren',['deleteChildren',['../struct_xan_node.html#a21b854c982060769c4a73b721abbb94d',1,'XanNode']]],
  ['dependinginsts',['dependingInsts',['../structir__instruction__metadata__t.html#a2d50999dee3d80f0344ecd81814ad875',1,'ir_instruction_metadata_t']]],
  ['dependsfrom',['dependsFrom',['../structir__instruction__metadata__t.html#a0f42a2cd0c0d481805eba08845c105b6',1,'ir_instruction_metadata_t']]],
  ['deptype',['depType',['../structdata__dep__arc__list__t.html#a48a2ecd4c3176c1c270a62dbc9e51c0b',1,'data_dep_arc_list_t']]],
  ['deserialize',['deserialize',['../struct___i_r_symbol_type.html#a7796d95cad3749e545d77cf4e863d1d0',1,'_IRSymbolType']]],
  ['destroynode',['destroyNode',['../struct_xan_node.html#a145e24530936237013209ce4675a8212',1,'XanNode']]],
  ['destroytree',['destroyTree',['../struct_xan_node.html#a7d0f2d7ff85dc1d9051975d93f5be5eb',1,'XanNode']]],
  ['destroytreeanddata',['destroyTreeAndData',['../struct_xan_node.html#a3ba382d7c8cf8fd9aa0d65cc7581c117',1,'XanNode']]],
  ['dla',['DLA',['../structt__system.html#a3043a2c0b0765ef3f4d937f5da8eb84e',1,'t_system']]],
  ['dla_5ftime',['dla_time',['../structt__profiler.html#af282e86f07c1c6968a7781c259d6e009',1,'t_profiler']]],
  ['do_5fjob',['do_job',['../structir__optimization__interface__t.html#a402d29e90fac82439ca9624279ab5d42',1,'ir_optimization_interface_t']]],
  ['dst',['dst',['../structcircuit__t.html#a4942bf8d6e248e07a6a6addf075fdef7',1,'circuit_t']]],
  ['dump',['dump',['../struct___i_r_symbol_type.html#afae757944c6dde58664be073fb6c8207',1,'_IRSymbolType']]]
];
