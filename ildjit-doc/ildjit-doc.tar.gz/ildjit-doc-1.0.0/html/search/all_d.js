var searchData=
[
  ['navigation_20through_20the_20cfg',['Navigation through the CFG',['../group___i_r_m_e_t_h_o_d___instruction_c_f_g.html',1,'']]],
  ['navigation_20through_20the_20instruction_2ddominance_20relation',['Navigation through the instruction-dominance relation',['../group___i_r_m_e_t_h_o_d___instruction_dominance.html',1,'']]],
  ['navigation_20through_20the_20ir_20instruction_20storing_20sequence',['Navigation through the IR instruction storing sequence',['../group___i_r_m_e_t_h_o_d___instruction_sequence.html',1,'']]],
  ['name',['name',['../structir__global__t.html#ae8d7b95f315c6b34401295ea0baef404',1,'ir_global_t::name()'],['../structir__method__t.html#ae8d7b95f315c6b34401295ea0baef404',1,'ir_method_t::name()'],['../structt__plugins.html#aa17c158dbdb8f6dfd95f48ee8ea83287',1,'t_plugins::name()']]],
  ['native_5fmethods_5felimination',['NATIVE_METHODS_ELIMINATION',['../group___codetools.html#ga82cf7c7bedcb29b782a417fdd24d49be',1,'codetool_types.h']]],
  ['neg_5fopcode',['NEG_OPCODE',['../cil__opcodes_8h.html#aa1434a7aa7def55174ccf713e20cd2d2',1,'cil_opcodes.h']]],
  ['nested_5fclass_5ftable',['NESTED_CLASS_TABLE',['../ecma__constant_8h.html#ae462164b64f509317b03cc2d06b62118',1,'ecma_constant.h']]],
  ['newarr_5fopcode',['NEWARR_OPCODE',['../cil__opcodes_8h.html#a74742cc3c4adea8c9ce337a0412484ac',1,'cil_opcodes.h']]],
  ['newemptybinary',['newEmptyBinary',['../loader_8h.html#a9a9933d7e737a62ca0b93a33ceee652b',1,'loader.h']]],
  ['newobj_5fopcode',['NEWOBJ_OPCODE',['../cil__opcodes_8h.html#a5440eeb71c9808f256d0bdccdedfa84f',1,'cil_opcodes.h']]],
  ['next',['next',['../struct_xan_list_item.html#a9182e2538357468538abe9ff9d6f26b9',1,'XanListItem']]],
  ['no_5fdecoder_5ffound',['NO_DECODER_FOUND',['../error__codes_8h.html#a98006b5ff7c5d60cac4b9d17afa438db',1,'error_codes.h']]],
  ['no_5fopcode',['NO_OPCODE',['../cil__opcodes_8h.html#a21a35ac005827d57bb1d4e319c4d968e',1,'cil_opcodes.h']]],
  ['no_5fread_5fpossible',['NO_READ_POSSIBLE',['../error__codes_8h.html#a8c87ab866d2f577fc3faf5a729563543',1,'error_codes.h']]],
  ['no_5fseek_5fpossible',['NO_SEEK_POSSIBLE',['../error__codes_8h.html#a6a606126fd654e147f7dd598c86383f2',1,'error_codes.h']]],
  ['nodes',['nodes',['../struct_xan_graph.html#a934238985536e3be581b94a5446d2bc8',1,'XanGraph']]],
  ['nop_5fopcode',['NOP_OPCODE',['../cil__opcodes_8h.html#a15c83c631889801919a59d41919de066',1,'cil_opcodes.h']]],
  ['noparam',['NOPARAM',['../group___i_r_language_data_types.html#ga6080016812bf04d6249087e62f227dff',1,'ir_language.h']]],
  ['not_5fopcode',['NOT_OPCODE',['../cil__opcodes_8h.html#ab5a0eabcf3ec24e799e090a07f2d0fd5',1,'cil_opcodes.h']]],
  ['null_5fcheck_5fremover',['NULL_CHECK_REMOVER',['../group___codetools.html#gad1a43d2600dc9b1495b3f5d032aa316c',1,'codetool_types.h']]]
];
