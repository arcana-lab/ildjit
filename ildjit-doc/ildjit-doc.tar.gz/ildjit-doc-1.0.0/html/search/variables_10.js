var searchData=
[
  ['tag',['tag',['../struct__ir__symbol__t.html#abd8852505bd6690ba7a046c2d58bb21a',1,'_ir_symbol_t']]],
  ['toinorderlist',['toInOrderList',['../struct_xan_node.html#abc88ad9d5c33c6983aec2ef7d46f709b',1,'XanNode']]],
  ['topostorderlist',['toPostOrderList',['../struct_xan_node.html#af6c3b5d517ccea50c5e9a233b76d9b18',1,'XanNode']]],
  ['topreorderlist',['toPreOrderList',['../struct_xan_node.html#a24fe49b6cefee0a9aa00064c2cf31237',1,'XanNode']]],
  ['total_5ftime',['total_time',['../structt__profiler.html#a210b9f0db9b3c5cd72e8c52ea28bb74f',1,'t_profiler']]],
  ['traceroptions',['tracerOptions',['../structir__system__behavior__t.html#af5df6592c390fcbc8916c30a9db494a7',1,'ir_system_behavior_t']]],
  ['trampolines_5ftime',['trampolines_time',['../structt__profiler.html#ae54d942953560e9d779bb5a57d1ccae9',1,'t_profiler']]],
  ['trampolinestaken',['trampolinesTaken',['../structt__profiler.html#a6c67fce322c730bb688670752afce811',1,'t_profiler']]],
  ['trampolinestakenbeforeentrypoint',['trampolinesTakenBeforeEntryPoint',['../structt__profiler.html#a6f3b95f1f31b8a80f440f9bd13b5dde7',1,'t_profiler']]],
  ['translatingset',['translatingSet',['../struct_static_memory_manager.html#af6caf74779eb016c3ffd6b6f97d62cb6',1,'StaticMemoryManager']]],
  ['type',['type',['../structinduction__variable__t.html#a826d42dd9722859cfa8c28fe03b1badc',1,'induction_variable_t::type()'],['../structir__item__t.html#a576041d54d6f4541510f2c76e195b7dd',1,'ir_item_t::type()'],['../structir__instruction__t.html#af531452212c42eff5846dffe5d840ac3',1,'ir_instruction_t::type()']]],
  ['type_5finfo',['type_info',['../structir__local__t.html#aef0672e0634448c16adf6966a7f3fe02',1,'ir_local_t']]],
  ['type_5finfos',['type_infos',['../structir__item__t.html#aee75517fe184854acf27a6cbc6f887e5',1,'ir_item_t']]]
];
