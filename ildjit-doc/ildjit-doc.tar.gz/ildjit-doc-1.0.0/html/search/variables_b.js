var searchData=
[
  ['name',['name',['../structir__global__t.html#ae8d7b95f315c6b34401295ea0baef404',1,'ir_global_t::name()'],['../structir__method__t.html#ae8d7b95f315c6b34401295ea0baef404',1,'ir_method_t::name()'],['../structt__plugins.html#aa17c158dbdb8f6dfd95f48ee8ea83287',1,'t_plugins::name()']]],
  ['next',['next',['../struct_xan_list_item.html#a9182e2538357468538abe9ff9d6f26b9',1,'XanListItem']]],
  ['nodes',['nodes',['../struct_xan_graph.html#a934238985536e3be581b94a5446d2bc8',1,'XanGraph']]]
];
