var searchData=
[
  ['jump_20instruction_20set',['Jump instruction set',['../group___i_r_language_instructions_jump.html',1,'']]],
  ['jmp_5fopcode',['JMP_OPCODE',['../cil__opcodes_8h.html#ad3aac4d88524cf859418ca276bb6e36e',1,'cil_opcodes.h']]]
];
