var searchData=
[
  ['remove',['Remove',['../group___i_r_m_e_t_h_o_d___data_dependences_remove.html',1,'']]],
  ['resolve_20symbols',['Resolve symbols',['../group___i_r_s_y_m_b_o_l_s___resolve.html',1,'']]],
  ['regular_20expressions',['Regular Expressions',['../group___r_e_g_e_x.html',1,'']]],
  ['run_20time_20checking',['Run time checking',['../group___runtime_checking.html',1,'']]],
  ['removing_20elements_20from_20a_20hash_20table',['Removing elements from a hash table',['../group___xan_hash_table_remove.html',1,'']]],
  ['removing_20elements_20from_20a_20list',['Removing elements from a list',['../group___xan_list_remove.html',1,'']]]
];
