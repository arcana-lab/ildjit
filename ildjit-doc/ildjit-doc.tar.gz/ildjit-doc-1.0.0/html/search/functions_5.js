var searchData=
[
  ['generator_5fbootstrapper',['generator_bootstrapper',['../system__manager_8h.html#a8e8ec33caff1bd3cb9a218631161e0d7',1,'system_manager.h']]],
  ['get_5fmetadata_5fstart_5fpoint',['get_metadata_start_point',['../iljit-utils_8h.html#acabf4b31407b364b34f9a55e78fe1f0c',1,'iljit-utils.h']]],
  ['getarrayslotsize',['getArraySlotSize',['../garbage__collector__interactions_8h.html#ad03fb2418a88380b2e26eacadb4cb2f3',1,'garbage_collector_interactions.h']]],
  ['getbestclockid',['getBestClockID',['../iljit-utils_8h.html#ac432a4efc3f01b3ca69df0e82af157ce',1,'iljit-utils.h']]],
  ['getreferencedobject',['getReferencedObject',['../garbage__collector__interactions_8h.html#a88e44c11ecd343a19d7f8224777ebb31',1,'garbage_collector_interactions.h']]],
  ['getrootset',['getRootSet',['../garbage__collector__interactions_8h.html#ab43aad286c2ec29edeed639c4af7e7f7',1,'garbage_collector_interactions.h']]],
  ['guid_5findex_5fis_5f32',['guid_index_is_32',['../iljit-utils_8h.html#a767ad89249a5e560809f4577ff8abc4c',1,'iljit-utils.h']]]
];
