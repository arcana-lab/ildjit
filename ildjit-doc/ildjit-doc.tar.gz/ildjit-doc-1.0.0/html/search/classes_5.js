var searchData=
[
  ['memorymanager',['MemoryManager',['../struct_memory_manager.html',1,'']]]
];
