var searchData=
[
  ['pointer_20data_20types',['Pointer data types',['../group___i_r_language_pointer_data_types.html',1,'']]],
  ['program',['Program',['../group___i_r_m_e_t_h_o_d___modify_program.html',1,'']]],
  ['program',['Program',['../group___i_r_m_e_t_h_o_d___program.html',1,'']]],
  ['partial_20compilation_20scheme',['Partial compilation scheme',['../group___partial_compilation_scheme.html',1,'']]],
  ['platform_20api',['Platform API',['../group___p_l_a_t_f_o_r_m___a_p_i.html',1,'']]],
  ['plugins',['Plugins',['../group___plugins.html',1,'']]],
  ['pipe',['Pipe',['../group___xan_pipe.html',1,'']]],
  ['priority_20queue',['Priority Queue',['../group___xan_queue.html',1,'']]]
];
