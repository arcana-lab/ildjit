var searchData=
[
  ['variables',['Variables',['../group___i_r_m_e_t_h_o_d___data_type_variable.html',1,'']]],
  ['variables_20defined',['Variables defined',['../group___i_r_m_e_t_h_o_d___instruction_define.html',1,'']]],
  ['variables_20used',['Variables used',['../group___i_r_m_e_t_h_o_d___instruction_uses.html',1,'']]],
  ['variables',['Variables',['../group___i_r_m_e_t_h_o_d___method___variables.html',1,'']]],
  ['variables',['Variables',['../group___i_r_m_e_t_h_o_d___modify_variables.html',1,'']]],
  ['v',['v',['../unionir__value__t.html#a6956c20eec9c84cc147ffba9a6a0551a',1,'ir_value_t']]],
  ['value',['value',['../structinduction__variable__t.html#ac402c3cb8d0bbeaeb6c6bf2d36ca9cf7',1,'induction_variable_t::value()'],['../structir__item__t.html#a10d181639b2c7a92b0fd4d84afc5a2aa',1,'ir_item_t::value()']]],
  ['var_5fmax',['var_max',['../structir__method__t.html#aefbb2c32e615da24ee5fcffb3ab3726e',1,'ir_method_t']]],
  ['var_5fnumber',['var_number',['../structir__local__t.html#a046573ce34c6cb1847f23b3f3b1f5ad6',1,'ir_local_t']]],
  ['variables_5flive_5frange_5fsplitting',['VARIABLES_LIVE_RANGE_SPLITTING',['../group___codetools.html#gacd991fc75d1d36a63d67780bacd4c6ba',1,'codetool_types.h']]],
  ['variables_5frenaming',['VARIABLES_RENAMING',['../group___codetools.html#ga70ccdd9f814cfd55e1008f61fdfec3bd',1,'codetool_types.h']]],
  ['vmmutex',['vmMutex',['../struct_i_r_v_m__t.html#acc9be586cf8d27f0b4ef92c2ee2b8f0a',1,'IRVM_t']]],
  ['volatile_5fopcode',['VOLATILE_OPCODE',['../cil__opcodes_8h.html#a4b34b54620e90d14c2b6d9bd643e0553',1,'cil_opcodes.h']]],
  ['variable',['Variable',['../group___xan_var.html',1,'']]]
];
